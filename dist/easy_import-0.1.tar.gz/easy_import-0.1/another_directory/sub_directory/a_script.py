# -*- coding: utf-8 -*-
"""
Created on Tue Sep 21 22:08:59 2021

@author: jt
"""

def quadruple(x):
    return 4 * x

def main():
    print(quadruple(5))
    
if __name__ == '__main__':
    main()