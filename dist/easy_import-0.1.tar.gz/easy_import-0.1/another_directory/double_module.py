# -*- coding: utf-8 -*-
"""
Created on Mon Sep 20 16:21:25 2021

@author: jt
"""


def double(x):
    return 2 * x

def main():
   print(double(3))

if __name__ == '__main__':
    main()
