# -*- coding: utf-8 -*-
"""
Created on Tue Sep 21 18:46:18 2021

@author: jt
"""

def treble(x):
    return 3 * x

def main():
    print(treble(10))
    
if __name__ == '__main__':
    main()