# -*- coding: utf-8 -*-
"""
Created on Tue Sep 21 21:56:45 2021

@author: jt
"""

def say_hello(name):
    print(f"Hello {name} !")
    
def main():
    say_hello("World")

if __name__ == '__main__':
    main()
    